package com.kmp.network.client

import androidx.compose.runtime.Composable

/**
 * iOS implementation of the ChuckerButton.
 * This is an empty implementation since Chucker is not available on iOS.
 */
@Composable
actual fun ChuckerButton() {
    // No-op implementation for iOS
} 