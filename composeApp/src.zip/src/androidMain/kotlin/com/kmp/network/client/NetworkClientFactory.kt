package com.kmp.network.client

import android.content.Context
import com.kmm.networkclient.AndroidContextProvider
import com.kmm.networkclient.NetworkClient
import com.kmm.networkclient.NetworkClientConfig
import com.kmm.networkclient.createPlatformNetworkClient

/**
 * Utility class for creating NetworkClients with Chucker integration.
 */
object NetworkClientFactory {
    
    /**
     * Creates a NetworkClient with Chucker integration.
     * 
     * @param config The network client configuration
     * @param context Optional context to use if the AndroidContextProvider is not initialized
     * @return A NetworkClient with Chucker integration
     */
    fun create(
        config: NetworkClientConfig = NetworkClientConfig(),
        context: Context? = null
    ): NetworkClient {
        // If a context is provided, use it to initialize the provider
        val appContext = context?.applicationContext ?: AndroidContextProvider.getApplicationContext()
        
        if (appContext != null) {
            // Initialize the context provider if not already done
            AndroidContextProvider.initialize(appContext)
        }
        
        // Use the platform-specific implementation
        return createPlatformNetworkClient(config)
    }
} 