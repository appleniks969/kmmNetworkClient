package com.kmp.network.client

import androidx.compose.foundation.layout.padding
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.chuckerteam.chucker.api.Chucker

/**
 * A button that opens the Chucker UI when clicked.
 * This should only be used in Android.
 */
@Composable
fun ChuckerInspectorButton() {
    val context = LocalContext.current
    
    Button(
        onClick = {
            // Open Chucker UI directly
            context.startActivity(Chucker.getLaunchIntent(context))
        },
        modifier = Modifier.padding(top = 8.dp)
    ) {
        Text("View Network Inspector")
    }
} 