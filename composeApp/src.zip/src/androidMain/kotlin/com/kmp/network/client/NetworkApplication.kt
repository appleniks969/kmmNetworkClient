package com.kmp.network.client

import android.app.Application
import com.kmm.networkclient.AndroidContextProvider

/**
 * Main application class for the Android app that initializes Chucker.
 */
class NetworkApplication : Application() {
    
    override fun onCreate() {
        super.onCreate()
        
        // Initialize the context provider for Chucker
        AndroidContextProvider.initialize(applicationContext)
    }
} 