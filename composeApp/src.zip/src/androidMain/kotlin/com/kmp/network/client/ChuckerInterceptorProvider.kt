package com.kmp.network.client

import android.content.Context
import com.chuckerteam.chucker.api.ChuckerCollector
import com.chuckerteam.chucker.api.ChuckerInterceptor
import com.chuckerteam.chucker.api.RetentionManager
import okhttp3.Interceptor

/**
 * Provider class for Chucker interceptor.
 * This class is in the composeApp module where Chucker dependencies are available.
 */
object ChuckerInterceptorProvider {
    
    /**
     * Creates a Chucker interceptor for network monitoring.
     * 
     * @param context The Android context
     * @return A configured Chucker interceptor
     */
    fun createInterceptor(context: Context): Interceptor {
        // Create a collector with a 1-hour retention period
        val chuckerCollector = ChuckerCollector(
            context = context,
            showNotification = true,
            retentionPeriod = RetentionManager.Period.ONE_HOUR
        )
        
        // Create and configure the Chucker interceptor
        return ChuckerInterceptor.Builder(context)
            .collector(chuckerCollector)
            .maxContentLength(250_000L)
            .redactHeaders(listOf("Authorization", "Bearer", "X-API-Key"))
            .alwaysReadResponseBody(true)
            .build()
    }
} 