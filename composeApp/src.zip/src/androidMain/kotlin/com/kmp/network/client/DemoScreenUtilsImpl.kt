package com.kmp.network.client

import androidx.compose.runtime.Composable

/**
 * Android implementation of the ChuckerButton.
 * This uses Chucker to show a network inspector UI.
 */
@Composable
actual fun ChuckerButton() {
    // Use the platform-specific implementation
    ChuckerInspectorButton()
} 