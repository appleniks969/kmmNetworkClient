package com.kmp.network.client.samples

import com.kmp.network.client.NetworkClientFactory
import com.kmm.networkclient.NetworkClientConfig
import com.kmm.networkclient.NetworkException
import io.ktor.client.plugins.logging.*

/**
 * Sample class demonstrating how to use NetworkClient with Chucker integration.
 * This is just an example - not meant to be used in production.
 */
class ChuckerUsageExample {
    
    // Create a NetworkClient with Chucker integration using the factory
    private val networkClient = NetworkClientFactory.create(
        config = NetworkClientConfig(
            baseUrl = "https://jsonplaceholder.typicode.com",
            enableLogging = true,
            logLevel = LogLevel.ALL
        )
    )
    
    /**
     * Sample method to demonstrate how to make a network request with the Chucker-enabled client.
     * The HTTP traffic will be visible in the Chucker UI.
     */
    suspend fun fetchSampleData(): List<SamplePost> {
        return try {
            networkClient.get<List<SamplePost>>(
                url = "/posts",
                headers = mapOf("Cache-Control" to "no-cache")
            )
        } catch (e: NetworkException) {
            // Handle errors
            emptyList()
        }
    }
    
    /**
     * Sample data class for demonstration
     */
    data class SamplePost(
        val id: Int,
        val userId: Int,
        val title: String,
        val body: String
    )
    
    /**
     * Cleanup resources
     */
    fun cleanup() {
        networkClient.close()
    }
} 