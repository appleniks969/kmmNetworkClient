package com.kmp.network.client

import androidx.compose.material.MaterialTheme
import androidx.compose.runtime.Composable

@Composable
fun App() {
    MaterialTheme {
        SimpleNetworkScreen()
    }
}