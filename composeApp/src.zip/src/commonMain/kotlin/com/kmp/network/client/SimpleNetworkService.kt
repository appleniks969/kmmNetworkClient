package com.kmp.network.client

import com.kmm.networkclient.Closeable
import com.kmm.networkclient.NetworkClient
import com.kmm.networkclient.NetworkClientConfig
import com.kmm.networkclient.createPlatformNetworkClient
import io.ktor.client.plugins.logging.*

/**
 * A simple service that demonstrates using the NetworkClient with Chucker integration.
 */
class SimpleNetworkService : Closeable {
    private val baseUrl = "https://jsonplaceholder.typicode.com"
    
    // Create a NetworkClient with platform-specific optimizations
    // This will use Chucker on Android automatically
    private val networkClient = createPlatformNetworkClient(
        config = NetworkClientConfig(
            baseUrl = baseUrl,
            enableLogging = true,
            logLevel = LogLevel.ALL
        )
    )
    
    /**
     * Fetches a list of posts from the JSONPlaceholder API.
     */
    suspend fun fetchPosts(): List<Post> {
        return networkClient.get(
            url = "/posts",
            headers = mapOf("Cache-Control" to "no-cache")
        )
    }
    
    /**
     * Closes the network client to free resources.
     */
    override fun close() {
        networkClient.close()
    }
} 