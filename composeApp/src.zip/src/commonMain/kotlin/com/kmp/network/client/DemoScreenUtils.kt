package com.kmp.network.client

import androidx.compose.runtime.Composable

/**
 * Platform-specific Chucker button.
 * On Android, this will show the Chucker UI button.
 * On other platforms, it will be empty.
 */
@Composable
expect fun ChuckerButton() 